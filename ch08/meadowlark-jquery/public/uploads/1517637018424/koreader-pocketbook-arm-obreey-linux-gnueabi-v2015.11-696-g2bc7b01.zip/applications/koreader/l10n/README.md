# How to sync this folder with transifex

1. install transifex client. For example: `apt-get install transifex-client`.

2. configure the client:
   http://support.transifex.com/customer/portal/articles/1000855-configuring-the-client

3. pull changes from transifex: `make pull`
